package dev.bogibek.nutritionxorazm.models

data class History(
    val product: Int,
    val quantity: Double
)
