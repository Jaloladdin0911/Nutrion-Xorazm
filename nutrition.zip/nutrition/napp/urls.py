from django.urls import path
from .views import PersonCheck, ProductLIST, HistoryPOST, HistoryGET, PersonNotCheck, WeeklyCaloriesGet

urlpatterns = [
    path("personcheck/", PersonCheck),
    path("product/list/", ProductLIST),
    path("history/post/<int:pk>/", HistoryPOST),
    path("history/get/<int:pk>/", HistoryGET),
    path("personnotcheck/", PersonNotCheck),
    path("weeklycaloriesget/<int:pk>/", WeeklyCaloriesGet)
]
