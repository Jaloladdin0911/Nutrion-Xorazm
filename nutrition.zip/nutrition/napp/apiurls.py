from django.urls import path
from .views import PersonGETUPDATEAPIView, PersonPOSTAPIView, HistoryDELETEAPIVIEW


urlpatterns = [
    path("person/getupdate/<int:pk>/", PersonGETUPDATEAPIView.as_view()),
    path("person/post/", PersonPOSTAPIView.as_view()),
    path("history/delete/<int:pk>/", HistoryDELETEAPIVIEW.as_view()),
]
