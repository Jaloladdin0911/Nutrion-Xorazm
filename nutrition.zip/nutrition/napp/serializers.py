from rest_framework import serializers
from .models import Person, Product, History


class PersonSer(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = "__all__"


class ProductSer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = "__all__"

class HistorySer(serializers.ModelSerializer):
    class Meta:
        model = History
        fields = "__all__"