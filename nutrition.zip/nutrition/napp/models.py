from django.db import models


# Create your models here.


class Person(models.Model):  # User class
    class Meta:
        db_table = "people"  # name of table in database

    username = models.CharField(max_length=50, unique=True)  # unique username of user
    password = models.CharField(max_length=50)  # password of user
    height = models.FloatField()  # height of user
    weight = models.FloatField()  # weight of user
    gender = models.CharField(
        max_length=6,
        choices=(("male", "male"), ("female", "female")),
        null=True,  # gender of user, can be chosen from 2 options
    )
    plan = models.CharField(
        max_length=7,
        choices=(("free", "free"), ("paid", "paid"), ("premium", "premium")),
        null=True,
    )  # current tariff plan that user is using, can be chosen from 3 options
    date_created = models.DateField(auto_now_add=True)
    time_created = models.TimeField(auto_now_add=True)

    def __str__(self) -> str:
        return str(self.username)  # returning person's username when Person object is called


class Product(models.Model):  # Product class
    class Meta:
        db_table = "products"  # name of table in database

    name = models.CharField(max_length=50)  # this is how category called
    photo = models.URLField()  # photo of product
    category = models.CharField(
        max_length=10,
        choices=(
            ("foods", "foods"),
            ("salads", "salads"),
            ("desserts", "desserts"),
            ("drinks", "drinks"),
            ("fruits", "fruits"),
        ),
    )  # category which product refers to, can be chosen from 5 options
    dose = models.CharField(
        max_length=10,
        choices=(
            ("portion", "portion"),
            ("gram", "gram"),
            ("piece", "piece"),
            ("milliliter", "milliliter"),
            ("liter", "liter")
        ),
    )  # this is measure unit of product, can be chosen from 4 options
    cps = (
        models.FloatField()
    )  # calories per serving, this is indicator of calories per measure unit of product
    description = models.TextField()  # description of product

    def __str__(self) -> str:
        return str(self.name)  # returning name of product when Product object is called


class History(models.Model):
    user = models.ForeignKey(to=Person, on_delete=models.CASCADE)
    product = models.ForeignKey(to=Product, on_delete=models.CASCADE)
    quantity = models.FloatField()
    date_added = models.DateField(auto_now_add=True)

    def __str__(self) -> str:
        return str(f"{self.user.username} {self.date_added}")
