from pprint import pprint
import requests

# data = {
#     "username": "user2",
#     "password": "password",
#     "height": 175,
#     "weight": 90,
#     "gender": "male",
#     "plan": "free",
# }

# print(requests.post(url="http://localhost:8000/api/person/post/", data=data).json())

pprint(requests.get(url="http://localhost:8000/history/get/1").json())
