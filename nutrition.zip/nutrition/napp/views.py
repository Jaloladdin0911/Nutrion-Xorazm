import json
from datetime import datetime, timedelta

from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.generics import (
    RetrieveUpdateAPIView,
    ListAPIView,
    RetrieveAPIView,
    CreateAPIView,
    DestroyAPIView,
)

from .models import Person, Product, History
from .serializers import PersonSer, ProductSer, HistorySer


# Create your views here.


class PersonGETUPDATEAPIView(RetrieveUpdateAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSer

    def get_serializer(self, *args, **kwargs):
        kwargs['partial'] = True
        return super().get_serializer(*args, **kwargs)


class PersonPOSTAPIView(CreateAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSer


class ProductLISTAPIView(ListAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSer


class ProductGETAPIView(RetrieveAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSer


@csrf_exempt
def ProductLIST(request: HttpRequest) -> HttpResponse:
    foods = list(Product.objects.filter(category="foods"))
    salads = list(Product.objects.filter(category="salads"))
    desserts = list(Product.objects.filter(category="desserts"))
    drinks = list(Product.objects.filter(category="drinks"))
    fruits = list(Product.objects.filter(category="fruits"))

    a, b, c, d, e = [], [], [], [], []

    for food in foods:
        food = food.__dict__
        del food["_state"]
        a.append(food)

    for salad in salads:
        salad = salad.__dict__
        del salad["_state"]
        b.append(salad)

    for dessert in desserts:
        dessert = dessert.__dict__
        del dessert["_state"]
        c.append(dessert)

    for drink in drinks:
        drink = drink.__dict__
        del drink["_state"]
        d.append(drink)

    for fruit in fruits:
        fruit = fruit.__dict__
        del fruit["_state"]
        e.append(fruit)
    json_data = json.dumps(
        {
            "success": True,
            "data": {"foods": a, "salads": b, "desserts": c, "drinks": d, "fruits": e},
            "message": "success",
        }
    )
    return HttpResponse(content=json_data, content_type="application/json")


@csrf_exempt
def PersonCheck(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        body = json.loads(request.body)
        username = body["username"]
        password = body["password"]
        print(username, password)
        try:
            person = Person.objects.get(username=username)
        except Person.DoesNotExist:
            json_data = json.dumps(
                {"success": False, "data": None, "message": "userdoesnotexist"}
            )
            return HttpResponse(content=json_data, content_type="application/json")

        if person:
            if person.password == password:
                dict_data = person.__dict__
                del dict_data["_state"]
                new_dict = {"success": True, "data": dict_data, "message": "success"}
                new_dict["data"]["date_created"] = new_dict["data"][
                    "date_created"
                ].isoformat()
                new_dict["data"]["time_created"] = new_dict["data"][
                    "time_created"
                ].isoformat()
                json_data = json.dumps(new_dict)
                return HttpResponse(content=json_data, content_type="application/json")
            else:
                json_data = json.dumps(
                    {"success": False, "data": None, "message": "incorrectpassword"}
                )
            return HttpResponse(content=json_data, content_type="application/json")
    return render(request, "usercheck.html")


@csrf_exempt
def PersonNotCheck(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        body = json.loads(request.body)
        username = body["username"]
        password = body["password"]
        try:
            person = Person.objects.get(username=username)
        except Person.DoesNotExist:
            json_data = json.dumps(
                {"success": True, "data": None, "message": "userdoesnotexist"}
            )
            return HttpResponse(content=json_data, content_type="application/json")

        if person:
            if person.password == password:
                dict_data = person.__dict__
                del dict_data["_state"]
                new_dict = {"success": False, "data": dict_data, "message": "useralreadyexists"}
                new_dict["data"]["date_created"] = new_dict["data"][
                    "date_created"
                ].isoformat()
                new_dict["data"]["time_created"] = new_dict["data"][
                    "time_created"
                ].isoformat()
                json_data = json.dumps(new_dict)
                return HttpResponse(content=json_data, content_type="application/json")
            else:
                json_data = json.dumps(
                    {"success": False, "data": None, "message": "useralreadyexists&incorrectpassword"}
                )
            return HttpResponse(content=json_data, content_type="application/json")
    return render(request, "usercheck.html")


@csrf_exempt
def HistoryPOST(request: HttpRequest, pk: int):
    if request.method == "POST":
        try:
            user = Person.objects.get(pk=pk)
            body = json.loads(request.body)
            prpk = body["product"]
            quantity = body["quantity"]
            product = Product.objects.get(pk=prpk)
        except Person.DoesNotExist:
            json_data = json.dumps(
                {"success": False, "data": None, "message": "userdoesnotexist"}
            )
            return HttpResponse(content=json_data, content_type="application/json")
        except Product.DoesNotExist:
            json_data = json.dumps(
                {"success": False, "data": None, "message": "productdoesnotexist"}
            )
            return HttpResponse(content=json_data, content_type="application/json")

        day = datetime.today().date()
        history = list(reversed(
            History.objects.filter(user=user, date_added=day)))
        for h in history:
            if prpk == h.product_id:
                a = History.objects.get(pk=h.id)
                a.quantity += int(quantity)
                a.save()
                json_data = json.dumps({"success": True, "data": 1, "message": "success"})
                return HttpResponse(content=json_data, content_type="application/json")

        history = History(user=user, product=product, quantity=quantity)
        history.save()
        json_data = json.dumps({"success": True, "message": "success"})
        return HttpResponse(content=json_data, content_type="application/json")
    return render(request, "history.html")


@csrf_exempt
def HistoryGET(request: HttpRequest, pk: int):
    try:
        user = Person.objects.get(pk=pk)
    except Person.DoesNotExist:
        json_data = json.dumps({"success": False, "message": "userdoesnotexist"})
        return HttpResponse(content=json_data, content_type="application/json")
    day = datetime.today() - timedelta(days=7)

    current_date = datetime.today().date()

    end_of_last_week = current_date
    start_of_last_week = end_of_last_week - timedelta(days=6)

    dates: list = []

    for i in range(7):
        date = start_of_last_week + timedelta(days=i)
        dates.append(date.strftime('%Y-%m-%d'))
    hst = []
    lst = []
    weekly = 0
    for d in reversed(dates):
        if History.objects.filter(user=pk, date_added=d):
            for i in History.objects.filter(user=pk, date_added=d):
                product = Product.objects.get(pk=i.product_id).__dict__
                name = product["name"]
                quantity = i.quantity
                cps = product["cps"]
                total = round(quantity * cps, 2)
                lst.append({
                    "id": i.pk,
                    "name": name,
                    "total": total
                })
                weekly += total
            hst.append({
                "date": d,
                "products": lst
            })
            lst = []
        else:
            hst.append({
                "date": d,
                "products": []
            })

    json_data = json.dumps(
        {"success": True, "data": hst, "total": weekly, "message": "success"}
    )
    return HttpResponse(content=json_data, content_type="application/json")



f = [
    (2, 300),
    (3, 157),
    (4, 97),
    (5, 250),
    (6, 350),
    (8, 350),
    (14, 200),
    (15, 350),
    (16, 400),
    (17, 200),
    (18, 100),
    (29, 200),
    (32, 50),
    (33, 100),
    (34, 100),
    (35, 50),
    (36, 44),
    (37, 44),
    (38, 40),
    (39, 50),
    (45, 300),
    (47, 52),
    (48, 105),
    (49, 62),
    (50, 62),
    (52, 47),
    (53, 39),
    (55, 53),
    (56, 53),
    (57, 61),
]


@csrf_exempt
def WeeklyCaloriesGet(request: HttpRequest, pk: int):
    try:
        user = Person.objects.get(pk=pk)
    except Person.DoesNotExist:
        json_data = json.dumps({"success": False, "message": "userdoesnotexist"})
        return HttpResponse(content=json_data, content_type="application/json")
    day = datetime.today() - timedelta(days=7)
    history = list(
        reversed(
            History.objects.filter(user=user, date_added__range=[day, datetime.today()])
        )
    )
    p = [Product.objects.get(pk=h.product_id).cps * h.quantity for h in history]
    weekly = round(sum(p), 2)
    need = 0 if weekly >= (21000 if user.gender=="male" else 17500) else (21000 if user.gender=="male" else 17500) - weekly
    r = []
    pn = [h.product_id for h in history]
    for i in f:
        if i[0] not in pn:
            r.append({
                "name": Product.objects.get(pk=i[0]).name,
                "ccal": i[1]
                })


    json_data = json.dumps(
        {"success": True, "total": weekly, "need": need, "recommend": r, "message": "success"}
    )
    return HttpResponse(content=json_data, content_type="application/json")

class HistoryDELETEAPIVIEW(DestroyAPIView):
    queryset = History.objects.all()
    serializer_class = HistorySer


