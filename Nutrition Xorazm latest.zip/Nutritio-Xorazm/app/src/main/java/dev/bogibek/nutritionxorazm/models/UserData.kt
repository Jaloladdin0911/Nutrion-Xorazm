package dev.bogibek.nutritionxorazm.models

data class UserData(
    val weight: Double? = null,
    val height: Double? = null,
)
