from django.contrib import admin
from .models import Person, Product, History

# Register your models here.

@admin.register(Person)
class PersonA(admin.ModelAdmin):
    list_display = ("username", "id", "gender", "height", "weight", "plan")

@admin.register(Product)
class ProductA(admin.ModelAdmin):
        list_display = ("name", "id", "dose")

@admin.register(History)
class HistoryA(admin.ModelAdmin):
    list_display = ("__str__", "product_id", "quantity")
